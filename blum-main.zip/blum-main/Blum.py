import argparse
import json
import random
import time
from datetime import datetime
from urllib.parse import parse_qs, unquote
import cloudscraper
from payload.payload import get_payloads

# Initialize scraper
requests = cloudscraper.create_scraper()

# Utility functions
def print_(message):
    now = datetime.now().isoformat(" ").split(".")[0]
    print(f"[{now}] {message}")

def make_request(method, url, headers=None, json=None, data=None):
    retry_count = 0
    while retry_count < 4:
        time.sleep(2)
        try:
            if method.upper() == "GET":
                response = requests.get(url, headers=headers, json=json)
            elif method.upper() == "POST":
                response = requests.post(url, headers=headers, json=json, data=data)
            elif method.upper() == "PUT":
                response = requests.put(url, headers=headers, json=json, data=data)
            else:
                raise ValueError("Invalid method.")
            
            if response.status_code >= 500:
                retry_count += 1
                print_(f"Server error: {response.status_code} | Retrying...")
            elif response.status_code >= 400:
                print_(f"Client error: {response.status_code} | {response.text}")
                return None
            else:
                return response
        except Exception as e:
            print_(f"Request failed: {e}")
            retry_count += 1
    return None

# Token management
def get_token(user_id):
    try:
        with open("tokens.json", "r") as f:
            tokens = json.load(f)
        return tokens.get(str(user_id))
    except FileNotFoundError:
        return None

def save_token(user_id, token):
    try:
        with open("tokens.json", "r") as f:
            tokens = json.load(f)
    except FileNotFoundError:
        tokens = {}
    tokens[str(user_id)] = token
    with open("tokens.json", "w") as f:
        json.dump(tokens, f, indent=4)

def delete_token(user_id):
    try:
        with open("tokens.json", "r") as f:
            tokens = json.load(f)
        tokens.pop(str(user_id), None)
        with open("tokens.json", "w") as f:
            json.dump(tokens, f, indent=4)
    except FileNotFoundError:
        pass

def delete_all_tokens():
    with open("tokens.json", "w") as f:
        json.dump({}, f, indent=4)

# Main task functions
def check_tasks(token):
    headers = create_headers(token)
    response = make_request("GET", "https://game-domain.blum.codes/api/v1/tasks", headers=headers)
    if response and response.status_code == 200:
        tasks = response.json()
        for main_task in tasks:
            main_title = main_task.get('title')
            sub_sections = main_task.get('subSections', [])
            for sub_section in sub_sections:
                process_sub_section(sub_section, token)
    else:
        print_("Failed to fetch tasks.")

def process_sub_section(sub_section, token):
    title = sub_section.get('title')
    print_(f"Main Task Title: {title}")
    tasks = sub_section.get('tasks', [])
    for task in tasks:
        handle_task(task, token)

def handle_task(task, token):
    title = task.get('title', "")
    status = task.get('status')
    reward = task.get('reward')

    if "invite" in title.lower() or "farm" in title.lower():
        print_(f"Skipping task: {title}")
        return

    if status == "CLAIMED":
        print_(f"Task claimed: {title} | Reward: {reward}")
    elif status == "NOT_STARTED":
        start_task(token, task["id"], title)
        if "play game" in title.lower():
            play_game_until(token, task["id"], title, 800, 1200)
        validate_task(token, task["id"], title)
        claim_task(token, task["id"], title)
    elif status == "READY_FOR_CLAIM":
        claim_task(token, task["id"], title)
    elif status == "READY_FOR_VALIDATE":
        validate_task(token, task["id"], title)
        claim_task(token, task["id"], title)
    else:
        print_(f"Task already started: {title} | Status: {status} | Reward: {reward}")

# Task actions
def start_task(token, task_id, title):
    url = f"https://game-domain.blum.codes/api/v1/tasks/{task_id}/start"
    headers = create_headers(token)
    response = make_request("POST", url, headers=headers)
    if response:
        print_(f"Task started: {title}")
    else:
        print_(f"Failed to start task: {title}")

def play_game_until(token, task_id, title, min_score, max_score):
    """Simulate playing a game until the score is between min_score and max_score."""
    current_score = 0
    print_(f"Playing game for task: {title}")
    while current_score < min_score or current_score > max_score:
        current_score = random.randint(700, 1300)  # Simulate score generation
        print_(f"Current score: {current_score}")
        if min_score <= current_score <= max_score:
            print_(f"Score achieved: {current_score} | Task Completed!")
            break
        time.sleep(1)

def validate_task(token, task_id, title, keyword=None):
    url = f"https://game-domain.blum.codes/api/v1/tasks/{task_id}/validate"
    headers = create_headers(token)
    payload = {"keyword": keyword} if keyword else {}
    response = make_request("POST", url, headers=headers, json=payload)
    if response:
        print_(f"Task validated: {title}")
    else:
        print_(f"Failed to validate task: {title}")

def claim_task(token, task_id, title):
    url = f"https://game-domain.blum.codes/api/v1/tasks/{task_id}/claim"
    headers = create_headers(token)
    response = make_request("POST", url, headers=headers)
    if response:
        print_(f"Task claimed: {title}")
    else:
        print_(f"Failed to claim task: {title}")

# Helper functions
def create_headers(token):
    return {
        'Authorization': f'Bearer {token}',
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.165 Mobile Safari/537.36',
    }

# Main execution
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-u", "--user", help="User ID", required=True)
    args = parser.parse_args()

    user_id = args.user
    token = get_token(user_id)
    if not token:
        print_("No token found for user. Please provide a valid token.")
    else:
        check_tasks(token)