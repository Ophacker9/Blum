## BLUM BOT

## BOT FEATURE

- Auto Play Game
- Auto Claim Daily

## COOMANDS
```
pkg install python rust git -y
```
```
pkg install git
```
   ```bash
   git clone https://github.com/Not-D4rkCipherX/blum.git
   ```
   ```bash
   cd blum
   ```
3. **ADD ACCOUNTS**
   ```
   nano query_id.txt
   ```
4.**START THE BOT**
```bash
python blum.py
```

**TUTORIAL AVAILABLE ON MY YT**
